<?php
namespace In2code\MyUserFuncs;

/**
 * DoSomething
 */
class DoSomething
{

    /**
     * @param string $content
     * @param array $configuration
     * @return string
     */
    public function now(string $content = '', array $configuration = []): string
    {
        return 'abc';
    }
}

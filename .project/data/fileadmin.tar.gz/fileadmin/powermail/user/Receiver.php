<?php
namespace In2code\PowermailReceiver\UserFunc;

class Receiver
{
  public function getReceivers()
  {
    return 'daniel.boxhammer@1234-yahoo-100.com, tuana.koehler@129-google-cs.com';
  }
}
